using NaughtyAttributes;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(RayCastDetector))]
[RequireComponent(typeof(GunBulletTracker))]
[RequireComponent(typeof(Timer))]
[RequireComponent(typeof(DecalSpawner))]
public class GunController : Weapon
{
    [SerializeField] private Transform _projectileSpawnTransform;
    [SerializeField] private GunContextEvent _onGunShotEvent;

    private GunConfig _gun => Config as GunConfig;
    private RayCastDetector _rayCastDetector;
    private GunBulletTracker _gunBulletTracker;
    private DecalSpawner _decalSpawner;
    private Timer _timer;

    public UnityEvent<GunConfig> OnShoot;
    public UnityEvent<GunConfig> OnReload;
    public UnityEvent<GunConfig> OnGunInitialized;
    public UnityEvent<Vector3> OnObjectHit;

    private void Awake()
    {
        _rayCastDetector = GetComponent<RayCastDetector>();
        _gunBulletTracker = GetComponent<GunBulletTracker>();
        _timer = GetComponent<Timer>();
        _decalSpawner = GetComponent<DecalSpawner>();

        _timer.SetTime(new TimeMS(CalculateDurationAfterShot(_gun.Stats.ShotsPerMinute)));
        _timer.StartTimer();

        SetHolder(transform.root.gameObject);

        Debug.Log($"[GUN CONTROLLER] Initialized gun with the following configuration: \n{_gun.Stats.ToString()} -");
    }

    private void Start()
    {
        OnGunInitialized?.Invoke(_gun);
    }

    private float CalculateDurationAfterShot(int shotsPerMinute) => 60.0f / (float)shotsPerMinute;

    public override bool Use(ItemUsageData usageData)
    {
        GunContext gunContext = new GunContext()
        {
            Holder = _holder,
            Gun = _gun,
            Direction = usageData.Direction.normalized,
            Origin = usageData.Origin,
            RayCastDetector = _rayCastDetector,
            BulletTracker = _gunBulletTracker,
            IsHeld = usageData.IsHeld,
            IsPressed = usageData.IsPressed,
            Timer = _timer,
            ProjectileSpawnTransform = _projectileSpawnTransform
        };

        bool wasShotSuccessful = _gun.Behaviour.Shoot(gunContext, out RaycastHit hit);

        if (!wasShotSuccessful)
            return false;

        OnShoot?.Invoke(_gun);
        _onGunShotEvent?.Invoke(gunContext);

        if (hit.collider != null)
        {
            OnObjectHit?.Invoke(hit.point);
            Debug.Log($"[GUN CONTROLLER] Shot object: {hit.collider.gameObject.name} at point: {hit.point.ToString()} -");
            _decalSpawner.SpawnDecal(
                hit.point, 
                Quaternion.LookRotation(-hit.normal), 
                hit.collider.gameObject.transform
            );
        }

        return true;
    }

    [Button("Force Reload")]
    public override void Reload()
    {
        if (_gunBulletTracker.BulletsRemaining >= _gun.Stats.TotalRounds)
            return;

        OnReload?.Invoke(_gun);
    }
}